%{
Run this file to compile the mex files if you need to
(or if the binaries work for your computer, then you can skip this)
This file also contains two simple test problems

I tested this on linux, so it might not work out-of-the-box on Windows or Mac OS,
but I don't foresee any major difficulties in getting it to work. 

Stephen Becker, Feb 14, 2012  srbecker@alumni.caltech.edu


See also lbfgsb.m and lbfgsb_wrapper.c

%}



% -- Download lbfgsb v. 3.0 from Jorge Nocedal's website -- 
% From his website: Condition for Use: This
% software is freely available, but we expect that all publications describing  work
% using this software , or all commercial products using it, quote at least one of
% the references given below. This software is released under the BSD License

url ='http://users.eecs.northwestern.edu/~nocedal/Software/Lbfgsb.3.0.tar.gz';
srcDir = untar(url,'./');


% Use -DDEBUG to define the "DEBUG" symbol, or -UDEBUG to undefine it
%   (if defined, it gives more verbose output when you run the program )

% run mex -setup if you haven't already...

% use -lblas if you have it, otherwise change it below to -lmwblas

if strcmp( mexext, 'mexa64' )
   disp('Try the included executable first; if that fails, then compile with mex');
else
  mex lbfgsb_wrapper.c -largeArrayDims  -UDEBUG ...
    Lbfgsb.3.0/lbfgsb.f Lbfgsb.3.0/linpack.f Lbfgsb.3.0/timer.f ...
    -lm -lblas  CFLAGS="\$CFLAGS -O3"
end

disp('Done compiling');
%% test the new function
disp('=== lbfgsb "driver1" test problem, 2D === ');
% Here's the test problem included with lbfgsb called 'driver1'

n   = 25;

l   = ones(n,1); u = l;
odd = 1:2:n;
even= 2:2:n;
l(odd) = 1.0;
u(odd) = 1.0e2;
l(even)= -1.0e2;
u(even)=  1.0e2;


opts    = struct( 'x0', 3*ones(n,1) );
opts.printEvery     = 1;
opts.m  = 5;

% trueSoln = zeros(n,1);
% opts.errFcn   = @(x) norm(x-trueSoln)/max(norm(trueSoln),1);

[x,f,info] = lbfgsb( @driver1, l, u, opts );

% The true objective value is 0.
if abs(f) < 1e-8
    disp('Success!');
else
    disp('Something didn''t work right :-(  ');
end

%% another test function, the 2D Rosenbrock function
disp('=== Rosenbrock test function, 2D === ');
n = 2;

fxy = @(x,y) 100*( y-x.^2).^2  +  (1-x ).^2 ;
f   = @(x)   fxy( x(1,:), x(2,:) );
gxy = @(x,y) [100*(4*x.^3-4*x.*y)+2*x-2; 100*(2*y-2*x.^2)];
g   = @(x)   gxy( x(1,:), x(2,:) );

% There are no constraints
l   = -inf(n,1);
u   = inf(n,1);

opts    = struct( 'x0', [-1.9;2] );
opts.printEvery     = 1;
opts.m  = 5;

trueSoln = [1;1];
opts.errFcn     = @(x) norm(x-trueSoln)/max(norm(trueSoln),1);
% Ask for very high accuracy
opts.pgtol      = 1e-10;
opts.factr      = 1e3;

% The {f,g} is another way to call it
[x,f,info] = lbfgsb( {f,g} , l, u, opts );

if abs(f) < 1e-8
    disp('Success!');
else
    disp('Something didn''t work right :-(  ');
end
